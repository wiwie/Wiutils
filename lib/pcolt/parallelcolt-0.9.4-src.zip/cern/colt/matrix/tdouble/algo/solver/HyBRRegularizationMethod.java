package cern.colt.matrix.tdouble.algo.solver;

public enum HyBRRegularizationMethod {
    GCV, WGCV, ADAPTWGCV, NONE
}
