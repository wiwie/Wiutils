package cern.colt.matrix.tdouble.algo.solver;

public enum HyBRInnerSolver {
    TIKHONOV, NONE
}
