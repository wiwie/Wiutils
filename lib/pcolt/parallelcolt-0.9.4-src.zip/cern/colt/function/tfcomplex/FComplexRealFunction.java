package cern.colt.function.tfcomplex;

public interface FComplexRealFunction {
    abstract public float apply(float[] x);
}
