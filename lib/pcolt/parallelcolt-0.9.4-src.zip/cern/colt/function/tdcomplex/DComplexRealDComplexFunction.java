package cern.colt.function.tdcomplex;

public interface DComplexRealDComplexFunction {
    abstract public double[] apply(double[] x, double y);
}
